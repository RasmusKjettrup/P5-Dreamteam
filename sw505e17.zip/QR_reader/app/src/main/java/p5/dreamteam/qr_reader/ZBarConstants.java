package p5.dreamteam.qr_reader;

/**
 * String constants used by ZBar
 */
public interface ZBarConstants {
    String SCAN_MODES = "SCAN_MODES";
    String SCAN_RESULT = "SCAN_RESULT";
    String SCAN_RESULT_TYPE = "SCAN_RESULT_TYPE";
    String ERROR_INFO = "ERROR_INFO";
}
