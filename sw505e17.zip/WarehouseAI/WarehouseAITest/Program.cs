﻿

namespace WarehouseAITest
{
    class Program
    {
        private static void Main(string[] args)
        {
        }
    }
}
