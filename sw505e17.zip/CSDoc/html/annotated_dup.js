var annotated_dup =
[
    [ "WarehouseAI", "namespace_warehouse_a_i.html", "namespace_warehouse_a_i" ],
    [ "WarehouseAITest", "namespace_warehouse_a_i_test.html", "namespace_warehouse_a_i_test" ]
];