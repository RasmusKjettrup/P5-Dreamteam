var dir_2bbbd72329649b329d37bdf4f5585a35 =
[
    [ ".NETFramework,Version=v4.5.2.AssemblyAttribute.cs", "obj_2_debug_2_8_n_e_t_framework_00_version_0Av4_85_82_8_assembly_attribute_8cs.html", null ]
];