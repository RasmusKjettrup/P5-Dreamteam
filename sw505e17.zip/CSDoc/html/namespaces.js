var namespaces =
[
    [ "WarehouseAI", "namespace_warehouse_a_i.html", "namespace_warehouse_a_i" ],
    [ "WarehouseAITest", "namespace_warehouse_a_i_test.html", null ]
];