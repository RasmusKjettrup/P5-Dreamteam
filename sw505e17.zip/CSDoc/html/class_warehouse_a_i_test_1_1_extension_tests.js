var class_warehouse_a_i_test_1_1_extension_tests =
[
    [ "PowerTest", "class_warehouse_a_i_test_1_1_extension_tests.html#aa91527665871b8c8e31c0bae44f45022", null ]
];