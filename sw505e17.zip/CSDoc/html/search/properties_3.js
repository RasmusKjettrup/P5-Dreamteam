var searchData=
[
  ['description',['Description',['../struct_warehouse_a_i_1_1_u_i_1_1_command.html#a1d8d6fddb32aa0ef27feaad06a771f42',1,'WarehouseAI::UI::Command']]]
];
