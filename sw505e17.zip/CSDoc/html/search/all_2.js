var searchData=
[
  ['books',['books',['../class_warehouse_a_i_1_1_frontier.html#a3f07bc76fc2bd54d242dcd24a362e9a8',1,'WarehouseAI::Frontier']]]
];
