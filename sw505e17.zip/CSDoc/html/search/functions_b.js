var searchData=
[
  ['randomlyaddbooks',['RandomlyAddBooks',['../class_warehouse_a_i_1_1_representation_1_1_warehouse_representation.html#a764aeff07e70dfebdfe9bb113a52aa60',1,'WarehouseAI::Representation::WarehouseRepresentation']]],
  ['removebook',['RemoveBook',['../class_warehouse_a_i_1_1_representation_1_1_shelf.html#a8623c84161cd9dea672e75f2d0dc7db3',1,'WarehouseAI::Representation::Shelf']]]
];
