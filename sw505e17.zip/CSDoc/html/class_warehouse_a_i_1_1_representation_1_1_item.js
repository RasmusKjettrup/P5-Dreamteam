var class_warehouse_a_i_1_1_representation_1_1_item =
[
    [ "Item", "class_warehouse_a_i_1_1_representation_1_1_item.html#ae309c385fc700d612cc5b2ba420918ad", null ],
    [ "AddOutgoingRelation", "class_warehouse_a_i_1_1_representation_1_1_item.html#aa7faeda5f8daa0e23ccf3269fb5ee518", null ],
    [ "Neighbours", "class_warehouse_a_i_1_1_representation_1_1_item.html#afd052c9dde1e8195eabf50d7ed4bc8be", null ],
    [ "Id", "class_warehouse_a_i_1_1_representation_1_1_item.html#ac9331d9ee5492585119791141fcb3627", null ],
    [ "IngoingRelations", "class_warehouse_a_i_1_1_representation_1_1_item.html#a6b5d7f4932e553046d3c236f29356736", null ],
    [ "ISBN", "class_warehouse_a_i_1_1_representation_1_1_item.html#a6bac200940512d5ea3f5a811f4b275c0", null ],
    [ "Name", "class_warehouse_a_i_1_1_representation_1_1_item.html#aabc080e81eb542ea3d14fdac610477d8", null ],
    [ "OutgoingRelations", "class_warehouse_a_i_1_1_representation_1_1_item.html#a27b2d4d265c27037476c6bb77d874830", null ],
    [ "Priority", "class_warehouse_a_i_1_1_representation_1_1_item.html#a6e20108b520a0dd79e7e0ddff1db0f22", null ]
];