var namespace_warehouse_a_i_test =
[
    [ "ExtensionTests", "class_warehouse_a_i_test_1_1_extension_tests.html", "class_warehouse_a_i_test_1_1_extension_tests" ],
    [ "ImportanceAlgorithmTests", "class_warehouse_a_i_test_1_1_importance_algorithm_tests.html", "class_warehouse_a_i_test_1_1_importance_algorithm_tests" ],
    [ "ItemDatabaseTest", "class_warehouse_a_i_test_1_1_item_database_test.html", "class_warehouse_a_i_test_1_1_item_database_test" ],
    [ "Program", "class_warehouse_a_i_test_1_1_program.html", null ],
    [ "WarehouseRepresentationTests", "class_warehouse_a_i_test_1_1_warehouse_representation_tests.html", "class_warehouse_a_i_test_1_1_warehouse_representation_tests" ],
    [ "WeightAlgorithmTests", "class_warehouse_a_i_test_1_1_weight_algorithm_tests.html", "class_warehouse_a_i_test_1_1_weight_algorithm_tests" ]
];