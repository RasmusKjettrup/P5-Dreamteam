var dir_dc897e63a06242b51c283c941404ec85 =
[
    [ "obj", "dir_2da63e5eb9d67c0096bfa975ebc0c3b0.html", "dir_2da63e5eb9d67c0096bfa975ebc0c3b0" ],
    [ "Properties", "dir_2f55637645728f4b0cc4689a61863d47.html", "dir_2f55637645728f4b0cc4689a61863d47" ],
    [ "ExtensionTests.cs", "_extension_tests_8cs.html", [
      [ "ExtensionTests", "class_warehouse_a_i_test_1_1_extension_tests.html", "class_warehouse_a_i_test_1_1_extension_tests" ]
    ] ],
    [ "ImportanceAlgorithmTests.cs", "_importance_algorithm_tests_8cs.html", [
      [ "ImportanceAlgorithmTests", "class_warehouse_a_i_test_1_1_importance_algorithm_tests.html", "class_warehouse_a_i_test_1_1_importance_algorithm_tests" ]
    ] ],
    [ "ItemDatabaseTest.cs", "_item_database_test_8cs.html", [
      [ "ItemDatabaseTest", "class_warehouse_a_i_test_1_1_item_database_test.html", "class_warehouse_a_i_test_1_1_item_database_test" ]
    ] ],
    [ "Program.cs", "est_2_program_8cs.html", [
      [ "Program", "class_warehouse_a_i_test_1_1_program.html", null ]
    ] ],
    [ "WarehouseRepresentationTests.cs", "_warehouse_representation_tests_8cs.html", [
      [ "WarehouseRepresentationTests", "class_warehouse_a_i_test_1_1_warehouse_representation_tests.html", "class_warehouse_a_i_test_1_1_warehouse_representation_tests" ]
    ] ],
    [ "WeightAlgorithmTests.cs", "_weight_algorithm_tests_8cs.html", [
      [ "WeightAlgorithmTests", "class_warehouse_a_i_test_1_1_weight_algorithm_tests.html", "class_warehouse_a_i_test_1_1_weight_algorithm_tests" ]
    ] ]
];