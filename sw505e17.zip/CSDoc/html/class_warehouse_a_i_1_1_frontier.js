var class_warehouse_a_i_1_1_frontier =
[
    [ "Frontier", "class_warehouse_a_i_1_1_frontier.html#a9175d825c10b4c037c95473857c726ae", null ],
    [ "books", "class_warehouse_a_i_1_1_frontier.html#a3f07bc76fc2bd54d242dcd24a362e9a8", null ],
    [ "route", "class_warehouse_a_i_1_1_frontier.html#a39d242058ff7181c54e7162179200404", null ],
    [ "weight", "class_warehouse_a_i_1_1_frontier.html#a465af088cb6c8871c77a8b1e408524c4", null ]
];