var class_warehouse_a_i_1_1_representation_1_1_shelf =
[
    [ "ItemInstance", "class_warehouse_a_i_1_1_representation_1_1_shelf_1_1_item_instance.html", "class_warehouse_a_i_1_1_representation_1_1_shelf_1_1_item_instance" ],
    [ "AddBook", "class_warehouse_a_i_1_1_representation_1_1_shelf.html#a6d4dcf59ff6f7ed4c994fe8ae1dd0757", null ],
    [ "Contains", "class_warehouse_a_i_1_1_representation_1_1_shelf.html#a698dc9e41d35056ca37ed4977ebf9e2b", null ],
    [ "GetNumberOfItem", "class_warehouse_a_i_1_1_representation_1_1_shelf.html#aa2c189834d44d6ed46e8bfa179f063e4", null ],
    [ "RemoveBook", "class_warehouse_a_i_1_1_representation_1_1_shelf.html#a8623c84161cd9dea672e75f2d0dc7db3", null ],
    [ "_itemInstances", "class_warehouse_a_i_1_1_representation_1_1_shelf.html#a340a5608d4cf73941acb729803714d45", null ],
    [ "Items", "class_warehouse_a_i_1_1_representation_1_1_shelf.html#a2d93ee9ae9c84060d4bbcc4df3ac0aa0", null ],
    [ "MaxCapacity", "class_warehouse_a_i_1_1_representation_1_1_shelf.html#a6488a22f0a068090813375ad33a187b0", null ],
    [ "RemaningCapacity", "class_warehouse_a_i_1_1_representation_1_1_shelf.html#ad6a210f5e62d3b4f7fe920c388ab1898", null ]
];