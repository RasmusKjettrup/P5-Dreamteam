var class_warehouse_a_i_1_1_representation_1_1_item_database =
[
    [ "ItemDatabase", "class_warehouse_a_i_1_1_representation_1_1_item_database.html#a4b649ca7ce9d83d6eb8ba1b1ed0e9ffb", null ],
    [ "AddBook", "class_warehouse_a_i_1_1_representation_1_1_item_database.html#a6045d89550475a588d3111644c440795", null ],
    [ "ImportItems", "class_warehouse_a_i_1_1_representation_1_1_item_database.html#a8382a68d15625ad63f39e9c03d55f301", null ],
    [ "ImportRelations", "class_warehouse_a_i_1_1_representation_1_1_item_database.html#a66c43d995789a6f3d5e52ad65a18a082", null ],
    [ "Items", "class_warehouse_a_i_1_1_representation_1_1_item_database.html#a8b8a5df2ac8c9712cd416940d4eec0e8", null ]
];