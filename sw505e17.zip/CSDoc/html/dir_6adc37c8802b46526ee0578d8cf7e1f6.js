var dir_6adc37c8802b46526ee0578d8cf7e1f6 =
[
    [ "obj", "dir_2d1613c31b8dd3a1536c4d77d313db94.html", "dir_2d1613c31b8dd3a1536c4d77d313db94" ],
    [ "Pathfinding", "dir_3d5784fa98d02de0962d7ce1410fc7ce.html", "dir_3d5784fa98d02de0962d7ce1410fc7ce" ],
    [ "Properties", "dir_93caa6d0c368d01dcc7dfa4c2beb5ebf.html", "dir_93caa6d0c368d01dcc7dfa4c2beb5ebf" ],
    [ "Representation", "dir_0c6e018d98a93e121dd900859883c7bc.html", "dir_0c6e018d98a93e121dd900859883c7bc" ],
    [ "ShortestPathGraph", "dir_b1eb12576cc592d692ddfccd22f3da9a.html", "dir_b1eb12576cc592d692ddfccd22f3da9a" ],
    [ "UI", "dir_3b1313a5f5f2f24f297ab2a28f986f3b.html", "dir_3b1313a5f5f2f24f297ab2a28f986f3b" ],
    [ "Algorithms.cs", "_algorithms_8cs.html", null ],
    [ "Extensions.cs", "_extensions_8cs.html", null ],
    [ "Frontier.cs", "_frontier_8cs.html", [
      [ "Frontier", "class_warehouse_a_i_1_1_frontier.html", "class_warehouse_a_i_1_1_frontier" ]
    ] ],
    [ "PlacementAlgorithmClass.cs", "_placement_algorithm_class_8cs.html", [
      [ "PlacementAlgorithmClass", "class_warehouse_a_i_1_1_placement_algorithm_class.html", null ]
    ] ],
    [ "Program.cs", "_program_8cs.html", null ],
    [ "WarehouseServerIO.cs", "_warehouse_server_i_o_8cs.html", null ]
];